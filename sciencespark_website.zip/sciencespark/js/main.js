// ── NAV & FOOTER INJECTION ──
const LOGO = '../images/logo.png';
const BASE = '..';

function getActivePage() {
  const path = window.location.pathname;
  if (path.includes('competitions')) return 'competitions';
  if (path.includes('events')) return 'events';
  if (path.includes('team')) return 'team';
  if (path.includes('partners')) return 'partners';
  if (path.includes('news')) return 'news';
  if (path.includes('gallery')) return 'gallery';
  if (path.includes('contact')) return 'contact';
  if (path.includes('join')) return 'join';
  if (path.includes('about')) return 'about';
  return 'home';
}

function isActive(page) {
  return getActivePage() === page ? 'active' : '';
}

function injectNav() {
  const nav = document.getElementById('main-nav');
  if (!nav) return;
  nav.innerHTML = `
  <nav class="navbar">
    <div class="navbar-inner">
      <a href="${BASE}/index.html" class="nav-brand">
        <img src="${LOGO}" alt="Science Spark Logo">
        <span class="nav-brand-name">Science Spark</span>
      </a>
      <div class="nav-links">
        <a href="${BASE}/index.html" class="${isActive('home')}">Home</a>
        <a href="${BASE}/pages/about.html" class="${isActive('about')}">About</a>
        <a href="${BASE}/pages/competitions.html" class="${isActive('competitions')}">Competitions</a>
        <a href="${BASE}/pages/events.html" class="${isActive('events')}">Events</a>
        <div class="nav-dropdown">
          <a href="${BASE}/pages/team.html" class="${isActive('team')}">Team</a>
          <div class="dropdown-menu">
            <a href="${BASE}/pages/team.html?dept=Leadership">Leadership</a>
            <a href="${BASE}/pages/team.html?dept=Management">Management</a>
            <a href="${BASE}/pages/team.html?dept=Administration">Administration</a>
            <a href="${BASE}/pages/team.html?dept=Publication">Publication</a>
            <a href="${BASE}/pages/team.html?dept=LWS">LWS</a>
            <a href="${BASE}/pages/team.html?dept=Quiz">Quiz</a>
            <a href="${BASE}/pages/team.html?dept=Photography">Photography</a>
            <a href="${BASE}/pages/team.html?dept=Research">Research & Dev</a>
            <a href="${BASE}/pages/team.html?dept=Project">Project</a>
            <a href="${BASE}/pages/team.html?dept=Concept">Concept & Planning</a>
            <a href="${BASE}/pages/team.html?dept=Arts">Arts & Culture</a>
            <a href="${BASE}/pages/team.html?dept=IT">IT</a>
            <a href="${BASE}/pages/team.html?dept=PR">Public Relations</a>
          </div>
        </div>
        <a href="${BASE}/pages/partners.html" class="${isActive('partners')}">Partners</a>
        <a href="${BASE}/pages/news.html" class="${isActive('news')}">News</a>
        <a href="${BASE}/pages/gallery.html" class="${isActive('gallery')}">Gallery</a>
        <a href="${BASE}/pages/contact.html" class="${isActive('contact')}">Contact</a>
        <a href="${BASE}/pages/join.html" class="nav-cta ${isActive('join')}">Join Us</a>
      </div>
      <button class="hamburger" onclick="toggleMobileNav()" aria-label="Menu">
        <span></span><span></span><span></span>
      </button>
    </div>
    <div class="mobile-nav" id="mobileNav">
      <a href="${BASE}/index.html">Home</a>
      <a href="${BASE}/pages/about.html">About</a>
      <a href="${BASE}/pages/competitions.html">Competitions</a>
      <a href="${BASE}/pages/events.html">Events</a>
      <a href="${BASE}/pages/team.html">Team</a>
      <a href="${BASE}/pages/partners.html">Partners</a>
      <a href="${BASE}/pages/news.html">News</a>
      <a href="${BASE}/pages/gallery.html">Gallery</a>
      <a href="${BASE}/pages/contact.html">Contact</a>
      <a href="${BASE}/pages/join.html" style="color:#4A90D9;font-weight:700">Join Us →</a>
    </div>
  </nav>`;
}

function injectFooter() {
  const footer = document.getElementById('main-footer');
  if (!footer) return;
  footer.innerHTML = `
  <footer class="site-footer">
    <div class="footer-inner">
      <div class="footer-grid">
        <div>
          <div class="footer-brand-logo">
            <img src="${LOGO}" alt="Science Spark">
            <span>Science Spark</span>
          </div>
          <p class="footer-tagline">A youth organization dedicated to spreading science, creativity, and innovation among students across Bangladesh.</p>
          <div class="footer-socials">
            <a href="https://www.facebook.com/share/1Eseyi6Dt4/" target="_blank" class="footer-social-btn" title="Facebook">
              <svg viewBox="0 0 24 24"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/></svg>
            </a>
            <a href="https://www.instagram.com/science.spark.official" target="_blank" class="footer-social-btn" title="Instagram">
              <svg viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,0.7)" stroke-width="2"><rect x="2" y="2" width="20" height="20" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.5" cy="6.5" r=".5" fill="rgba(255,255,255,0.7)"/></svg>
            </a>
            <a href="https://wa.me/8801716455276" target="_blank" class="footer-social-btn" title="WhatsApp">
              <svg viewBox="0 0 24 24" fill="rgba(255,255,255,0.7)"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347zM12 0C5.373 0 0 5.373 0 12c0 2.124.557 4.133 1.531 5.88L0 24l6.31-1.508A11.953 11.953 0 0 0 12 24c6.627 0 12-5.373 12-12S18.627 0 12 0zm0 21.818a9.818 9.818 0 0 1-5.007-1.372l-.36-.213-3.727.891.933-3.617-.235-.374A9.818 9.818 0 0 1 2.182 12C2.182 6.57 6.57 2.182 12 2.182c5.43 0 9.818 4.388 9.818 9.818 0 5.43-4.388 9.818-9.818 9.818z"/></svg>
            </a>
          </div>
        </div>
        <div class="footer-col">
          <h4>Pages</h4>
          <ul>
            <li><a href="${BASE}/pages/about.html">About Us</a></li>
            <li><a href="${BASE}/pages/competitions.html">Competitions</a></li>
            <li><a href="${BASE}/pages/events.html">Events</a></li>
            <li><a href="${BASE}/pages/team.html">Our Team</a></li>
            <li><a href="${BASE}/pages/gallery.html">Gallery</a></li>
          </ul>
        </div>
        <div class="footer-col">
          <h4>Get Involved</h4>
          <ul>
            <li><a href="${BASE}/pages/join.html">Join Science Spark</a></li>
            <li><a href="${BASE}/pages/partners.html">Partner with Us</a></li>
            <li><a href="${BASE}/pages/competitions.html">Register for Events</a></li>
            <li><a href="${BASE}/pages/contact.html">Contact Us</a></li>
          </ul>
        </div>
        <div class="footer-col">
          <h4>Contact</h4>
          <ul>
            <li><a href="mailto:sciencespark.official.bd@gmail.com">Email Us</a></li>
            <li><a href="tel:+8801716455276">+880 1716-455276</a></li>
            <li><a href="https://wa.me/8801716455276" target="_blank">WhatsApp</a></li>
            <li><a href="https://www.facebook.com/share/1Eseyi6Dt4/" target="_blank">Facebook Page</a></li>
            <li><a href="https://www.instagram.com/science.spark.official" target="_blank">Instagram</a></li>
          </ul>
        </div>
      </div>
      <div class="footer-bottom">
        <p class="footer-copy">© 2026 <span>Science Spark</span>. All rights reserved.</p>
        <p class="footer-copy">Ignite Youth Minds · Bangladesh</p>
      </div>
    </div>
  </footer>`;
}

function toggleMobileNav() {
  document.getElementById('mobileNav')?.classList.toggle('open');
}

document.addEventListener('DOMContentLoaded', () => {
  injectNav();
  injectFooter();
});
